import { LoggerService } from '../Logger/logger.service';
import { EmicalcService } from './emicalc.service'
describe('EmicalcService', () => {
  let testVariable: any;
  // beforeEach(() => {
  //    testVariable = {};
  // }
  // )
  
  it('should add two integers', () => {
    let mockloggerService  = jasmine.createSpyObj('loggerService',['log']);
    //spyOn(loggerService, 'log').and.callThrough();
   const calc = new EmicalcService(mockloggerService);
    let result = calc.add(3,6)
    expect(result).toBe(9);
    expect(mockloggerService.log).toHaveBeenCalledTimes(1);
  });
  it('should subtract two integers', () => {
    let mockloggerService  = jasmine.createSpyObj('loggerService',['log']);
    //spyOn(loggerService, 'log');
   const calc = new EmicalcService(mockloggerService);
    let result = calc.sub(6,6);
    expect(result).toBe(0);
    expect(mockloggerService.log).toHaveBeenCalledTimes(1);
  });
  
});

//CRUD operation Contact Service , getContactOfUser 

// it('should return the correct contact of the user', () => {
//       //arrange 
//       // testVariable.a = false;
//       //act 
//       testVariable.a = true;
//       //assert
//       expect(testVariable.a).toBe(true);
//     }
//     );
  