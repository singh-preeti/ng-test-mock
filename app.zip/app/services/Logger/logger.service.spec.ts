// import { TestBed } from '@angular/core/testing';

// import { LoggerService } from './logger.service';

// describe('LoggerService', () => {
//   let service: LoggerService;
//   beforeAll( () => {
//    service = new LoggerService();
//   })
//   //scenario1
//   it('should not have any messeges at starting', () => {
//   //arrange
//   //const service = new LoggerService();
//   //act
//   let count = service.messages.length;
//   //assert
//   expect(count).toBe(0);
//   });
//  //scenario2
//   it('should add the messege when log is called', () => {
//     //arrange
//    // const service = new LoggerService();
//     //act
//     service.log('message');
//     //assert
//     expect(service.messages.length).toBe(1);
//     });
//    //scenario3
//     it('should clear all the messeges when clear is called', () => {
//       //arrange
//       //const service = new LoggerService();
//       service.log('message');
//       //act
//       service.clear();
//       //assert
//       expect(service.messages.length).toBe(0);
//       });
// });
