import { TypenstrengthPipe } from './typenstrength.pipe';

describe('TypenstrengthPipe', () => {
  it('create an instance', () => {
    const pipe = new TypenstrengthPipe();
    expect(pipe).toBeTruthy();
  });
  it ('should display weak if 7 value is passed' ,() => {
    const pipe = new TypenstrengthPipe();
    expect(pipe.transform(7)).toEqual('7(weak)')
  })
})

