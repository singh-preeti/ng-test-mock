import  { Posts } from 'src/app/models/Posts';
import { PostsComponent } from './posts.component';
import { of } from 'rxjs';
describe('Posts Component',() => {
    let POSTS : Posts[];
    let component: PostsComponent;
    let mockPostService : any;
    beforeEach( () =>{
        POSTS = [ 
            {
        id: 1,
        body: 'angular component test',
        title: 'ng testing',
    },
    {
        id: 2,
        body: 'angular service test',
        title: 'ng service test',
    },
    {
        id: 3,
        body: 'angular dependency test',
        title: 'dependency injection',
    },
]
mockPostService = jasmine.createSpyObj(['getPosts', 'deletePost']);
component = new PostsComponent(mockPostService);
    });
    describe('delete', () => {
        beforeEach(() => {
          mockPostService.deletePost.and.returnValue(of(true));
          component.posts = POSTS;
        });
        it('should delete the selected Post from the posts', () => {
          component.delete(POSTS[2]);
    
          expect(component.posts.length).toBe(2);
        });
    
   })
    
})