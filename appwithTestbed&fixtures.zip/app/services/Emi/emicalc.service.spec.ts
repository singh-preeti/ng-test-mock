import { LoggerService } from '../Logger/logger.service';
import { EmicalcService } from './emicalc.service'
describe('EmicalcService', () => {
  let testVariable: any;
  let mockloggerService: any;
  let calc: EmicalcService;
  beforeAll( () => {})
  beforeEach(() => {
    console.log("before each called!");
     mockloggerService  = jasmine.createSpyObj('loggerService',['log']);
     calc = new EmicalcService(mockloggerService);
  }
  )
  afterAll( () => {})
  
  it('should add two integers', () => {
    
    //spyOn(loggerService, 'log').and.callThrough();
    console.log("add method is called!");
    let result = calc.add(3,6)
    expect(result).toBe(9);
    expect(mockloggerService.log).toHaveBeenCalledTimes(1);
  });
  it('should subtract two integers', () => {
    console.log("subtract method is called!");
    //spyOn(loggerService, 'log');
    let result = calc.sub(6,6);
    expect(result).toBe(0);
    expect(mockloggerService.log).toHaveBeenCalledTimes(1);
  });
  
});

//CRUD operation Contact Service , getContactOfUser 

// it('should return the correct contact of the user', () => {
//       //arrange 
//       // testVariable.a = false;
//       //act 
//       testVariable.a = true;
//       //assert
//       expect(testVariable.a).toBe(true);
//     }
//     );
  