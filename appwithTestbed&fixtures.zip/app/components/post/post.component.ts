import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Posts } from 'src/app/models/Posts';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css'],
})
export class PostComponent {
  @Input() post!: Posts;
  @Output() delete = new EventEmitter<Posts>();

  onDeletePost(event: Event) {
    event.preventDefault();
    this.delete.emit(this.post);
  }
}